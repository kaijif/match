import requests
import pandas as pd
import json


def update_ranking_tables():
    token = 'Bearer ' + requests.post('https://www.usta.com/etc/usta/nologinjwt.nljwt.json').json()['access_token']
    headers = {'Authorization': token}
    gens = ['M', 'F']
    dis_gens = {'M': 'Boys\'', 'F': 'Girls\''}
    ages = [12, 14, 16, 18]
    for gen in gens:
        for age in ages:
            outs = []
            keep_going = True
            num = 1
            while keep_going:
                print(f'Updating {dis_gens[gen]} {age} & under Singles, {num}% done.')
                json_data = json.loads(
                    '{"pagination":{"pageSize":100,"currentPage":1},"selection":{"catalogId":"JUNIOR_NULL_' + gen + '_STANDING_Y' + str(
                        age) + '_UNDER_NULL_NULL_NULL"}}')
                json_data['pagination']['currentPage'] = num
                r = requests.post('https://services.usta.com/v1/dataexchange/rankings/search/public', json=json_data,
                                  headers=headers)
                if not r.json()['data']:
                    break
                for out in r.json()['data']:
                    outs.append(list(out.values())[:6])
                num += 1
            outs = pd.DataFrame(outs)
            outs.columns = ['Name', 'UAID', 'City', 'State', 'Points', 'Rank']
            outs = outs[['Name', 'City', 'State', 'Points', 'Rank']]
            outs['City, State'] = outs['City'] + ', ' + outs['State']
            outs = outs.drop('City', 1)
            outs = outs.drop('State', 1)
            outs = outs.set_index('Rank')
            with open(f'Dependencies/tables/{dis_gens[gen]} {age} & under Singles.csv', 'w') as file:
                outs.to_csv(file)



if __name__ == '__main__':
    update_ranking_tables()
