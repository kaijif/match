import requests
import pandas as pd
from selenium import webdriver
import time
import numpy as np

target_site = str(input('Target site-player\'s tab link here: '))
def query_utr(player_name):
    data_out = []
    cookies = {
        'jwt': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNZW1iZXJJZCI6IjM3MTE5MCIsImVtYWlsIjoiZnNqaWFuQGhvdG1haWwuY29tIiwiVmVyc2lvbiI6IjEiLCJEZXZpY2VMb2dpbklkIjoiNjM3NjgwMyIsIm5iZiI6MTYxNzYzNTI1MSwiZXhwIjoxNjIwMjI3MjUxLCJpYXQiOjE2MTc2MzUyNTF9.MJ1Juwuc-49uT6xyLRmal9g4gQNBZ2CO5HnJxnPt6d0'
    }
    payload = {
        'query': f'{player_name}'
    }
    utr_request = requests.get('https://app.myutr.com/api/v2/search/players', params=payload, cookies=cookies)
    utr_response = utr_request.json()
    for player in utr_response['hits']:
        data_out.append(player['source'])
    included_keys = ["displayName", "singlesUtr", "display"]
    clean_data_out = []
    for player in data_out:
        clean_dict = {k: v for k, v in player.items() if k in included_keys}
        clean_dict['name'] = clean_dict.pop('displayName')
        if clean_dict['name'] == player_name:
            clean_data_out.append(clean_dict)
    out = pd.DataFrame(clean_data_out)
    if not out.empty:
        out = out[['name', 'singlesUtr']]
    else:
        out = pd.DataFrame([player_name, 'NaN']).transpose()
        out.columns = ['name', 'singlesUtr']
    out = out[['name', 'singlesUtr']]
    out = out.sort_values(by='singlesUtr', ascending=False).iloc[0]
    return out


def query_usta_ranking(name, div):
    key = pd.read_csv('ranking_keys.csv', index_col='Div').to_dict()['Code'][div]
    r = requests.get(f'https://static.dwcdn.net/data/{key}.csv')

    with open("table.csv", "wb") as f:
        for chunk in r.iter_content(chunk_size=16 * 1024):
            f.write(chunk)

    df = pd.read_csv('table.csv', index_col='Rank')
    df['Name'] = df['Name'].str.upper()
    out = df[df['Name'] == name].index.tolist() if len(df[df['Name'] == name].index.tolist()) >= 2 else df[df['Name'] == name].index.tolist()[0] if df[df['Name'] == name].index.tolist() else 'NaN'
    return out if isinstance(out, list) else [out]


def query_tourn(site):
    driver = webdriver.Chrome()
    driver.get(site)
    time.sleep(3)
    list_of_tables = pd.DataFrame()
    if 'Acceptance lists' in driver.page_source:
        div = 1
        while div < 20:
            driver.find_element_by_xpath(
                '//*[@id="tournaments"]/div/div/div/div[3]/div/div/div/div/div/div/div').click()
            try:
                driver.find_element_by_xpath(f'//*[@id="menu-"]/div[3]/ul/li[{int(div)}]').click()
            except:
                break
            if 'Main draw' not in driver.page_source:
                div += 1
            else:
                list_of_tables = list_of_tables.append(pd.read_html(driver.page_source)[2].drop('Position',axis=1))
                div += 1
        driver.close()
        processed = list_of_tables
        processed['Player name'].apply(lambda x: x.upper())
        new_li = []
        for events in processed['Events'].tolist():
            if len(events.split(',')) == 1:
                if events.endswith('Doubles'):
                    new_li.append('NaN')
                    continue
                else:
                    new_li.append(events)
                    continue
            if '/' in events:
                new_li.append('NaN')
                continue

            for event in events.split(','):
                if event.endswith('Doubles'):
                    pass
                elif event.endswith('Singles'):
                    new_li.append(event.lstrip())
        processed['Events'] = new_li
        processed = processed[processed['Events'] != 'NaN']
        processed = processed.set_index(pd.Series([ind for ind in range(1, len(processed.index) + 1)]))
    else:
        list_of_tables = pd.read_html(driver.page_source)[2]
        processed = list_of_tables.drop(['Unnamed: 3', 'Unnamed: 4'], axis=1)
        processed = processed[processed.nunique(1) > 1]
        new_li = []
        for events in processed['Events'].tolist():
            if len(events.split(',')) == 1:
                if events.endswith('Doubles'):
                    new_li.append('NaN')
                    continue
                else:
                    new_li.append(events)
                    continue
            if '/' in events:
                new_li.append('NaN')
                continue

            for event in events.split(','):
                if event.endswith('Doubles'):
                    pass
                elif event.endswith('Singles'):
                    new_li.append(event.lstrip())
        names = []
        for name in processed['Player name']:
            name = name.split(', ')
            name.reverse()
            name = [name_part.lower().capitalize() for name_part in name]
            sep = ' '
            name = sep.join(name)
            names.append(name)
        processed['Player name'] = names
        processed['Events'] = new_li
        processed = processed[processed['Events'] != 'NaN']
        processed = processed.set_index(pd.Series([ind for ind in range(1, len(processed.index) + 1)]))
        driver.close()
    return processed


tourn = query_tourn(target_site)
ind = 1
base = pd.DataFrame()
for player in tourn['Player name'].tolist():
    print(f'Looking up info for {player}')
    utr = query_utr(player)
    utr['USTA rank'] = ' OR '.join(str(rank) for rank in query_usta_ranking(player.upper(), tourn['Events'][ind]))
    utr['Event'] = tourn['Events'][ind]
    base = base.append(utr)
    ind += 1
base = base.reset_index(drop=True)
base = base.drop_duplicates()
# base.to_csv('out.csv', index=False)
with pd.ExcelWriter('out.xlsx') as writer:
    for div in list(base['Event'].unique()):
        kairrie = query_utr('Kairrie Fu')
        print('Writing.')
        kairrie['USTA rank'] = query_usta_ranking('Kairrie Fu'.upper(), div)[0]
        kairrie['Event'] = div
        print('Writing..')
        if kairrie['USTA rank'] != 'NaN':
            per_base = base[base['Event'] == div].append(kairrie)
        kaiji = query_utr('Kaiji Fu')
        kaiji['USTA rank'] = query_usta_ranking('Kaiji Fu'.upper(), div)[0]
        kaiji['Event'] = div
        print('Writing...')
        if kaiji['USTA rank'] != 'NaN':
            per_base = per_base.append(kaiji)
        per_base = per_base[['name', 'USTA rank', 'singlesUtr', 'Event']]
        per_base['USTA rank'] = pd.to_numeric(per_base['USTA rank'].replace('NaN', 0))
        per_base = per_base.sort_values(by='USTA rank', ascending=False)
        per_base.to_excel(writer, sheet_name=div, index=False)
print(base)
