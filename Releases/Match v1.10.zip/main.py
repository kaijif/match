import requests
import pandas as pd
from datetime import date
pd.options.mode.chained_assignment = None
from selenium import webdriver
import time
from openpyxl import load_workbook
import sys

try:
    target_site = sys.argv[1]
except:
    target_site = str(input('Target site-player\'s tab link here: '))


def query_utr(player_name):
    data_out = []
    cookies = {
        'jwt': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNZW1iZXJJZCI6IjM3MTE5MCIsImVtYWlsIjoiZnNqaWFuQGhvdG1haWwuY29tIiwiVmVyc2lvbiI6IjEiLCJEZXZpY2VMb2dpbklkIjoiNjM3NjgwMyIsIm5iZiI6MTYxNzYzNTI1MSwiZXhwIjoxNjIwMjI3MjUxLCJpYXQiOjE2MTc2MzUyNTF9.MJ1Juwuc-49uT6xyLRmal9g4gQNBZ2CO5HnJxnPt6d0'
    }
    payload = {
        'query': f'{player_name}'
    }
    utr_request = requests.get('https://app.myutr.com/api/v2/search/players', params=payload, cookies=cookies)
    utr_response = utr_request.json()
    for player in utr_response['hits']:
        data_out.append(player['source'])
    included_keys = ["displayName", "singlesUtr", "display"]
    clean_data_out = []
    for player in data_out:
        clean_dict = {k: v for k, v in player.items() if k in included_keys}
        clean_dict['name'] = clean_dict.pop('displayName')
        if clean_dict['name'].upper() == player_name.upper():
            clean_data_out.append(clean_dict)
    out = pd.DataFrame(clean_data_out)
    if not out.empty:
        out = out[['name', 'singlesUtr']]
    else:
        out = pd.DataFrame([player_name, 'NaN']).transpose()
        out.columns = ['name', 'singlesUtr']
    out = out[['name', 'singlesUtr']]
    out = out.sort_values(by='singlesUtr', ascending=False).iloc[0]
    return out

def update_ranking_tables():
    keys = pd.read_csv('ranking_keys.csv', index_col='Div').to_dict()['Code']
    divs = list(keys.keys())
    for div in divs:
        print('Updating ranking tables.')
        r = requests.get(f'https://static.dwcdn.net/data/{keys[div]}.csv')

        with open(f"tables/{div}.csv", "wb") as f:
            for chunk in r.iter_content(chunk_size=16 * 1024):
                f.write(chunk)


def query_usta_ranking(name, div):
    df = pd.read_csv(f'tables/{div}.csv', index_col='Rank')
    df['Name'] = df['Name'].str.upper()
    out = [df[df['Name'] == name].index.tolist()[0]] if len(df[df['Name'] == name].index.tolist()) >= 2 else df[
        df['Name'] == name].index.tolist() if df[df['Name'] == name].index.tolist() else ['NaN']
    out.append(df[df['Name'] == name]['City, State'].tolist()[0]) if df[df['Name'] == name][
        'City, State'].tolist() else out.append('NaN')
    return out


def query_tourn(site):
    driver = webdriver.Chrome()
    driver.get(site)
    time.sleep(3)
    list_of_tables = pd.DataFrame()
    driver.find_element_by_xpath('//*[@id="cookie-bar"]/p/a[2]').click()
    if 'Acceptance lists' in driver.page_source:
        div = 1
        while div < 20:
            driver.find_element_by_xpath(
                '//*[@id="tournaments"]/div/div/div/div[3]/div/div/div/div/div/div/div').click()
            try:
                driver.find_element_by_xpath(f'//*[@id="menu-"]/div[3]/ul/li[{int(div)}]').click()
            except:
                break
            if 'Main draw' not in driver.page_source:
                div += 1
            else:
                name = driver.find_element_by_xpath(
                    '//*[@id="tournaments"]/div/div/div/div[3]/div/div/div/div/div/div/div').text
                table = pd.read_html(driver.page_source)[2].drop('Position', axis=1)
                table['Events'] = [name for _ in range(len(table.index))] if not name.endswith('Doubles') else ['NaN'
                                                                                                                for _ in
                                                                                                                range(
                                                                                                                    len(table.index))]
                list_of_tables = list_of_tables.append(table)
                div += 1
        driver.close()
        processed = list_of_tables
        processed['Player name'].apply(lambda x: x.upper())
        processed = processed[processed['Events'] != 'NaN']
        processed = processed.set_index(pd.Series([ind for ind in range(1, len(processed.index) + 1)]))
    else:
        list_of_tables = pd.read_html(driver.page_source)[2]
        processed = list_of_tables.drop(['Unnamed: 3', 'Unnamed: 4'], axis=1)
        processed = processed[processed.nunique(1) > 1]
        extras = pd.DataFrame()
        new_li = []
        ind = 0
        for events in processed['Events'].tolist():
            if len(events.split(',')) == 1:
                if events.endswith('Doubles'):
                    new_li.append('NaN')
                    continue
                else:
                    new_li.append(events)
                    continue
            if '/' in events:
                new_li.append('NaN')
                continue

            if len(events.split(',')) > 2:
                cand_events = []
                for event in events.split(','):
                    if event.endswith('Doubles'):
                        pass
                    elif event.endswith('Singles'):
                        cand_events.append(event)
                new_li.append(sorted(cand_events, reverse=True)[0].lstrip())
                for cand_event in cand_events[1:]:
                    extras = extras.append(pd.DataFrame(processed['Player name'][ind], cand_event))
                continue

            if len(events.split(',')) == 2 and events.split(', ')[0].endswith('Singles') and events.split(', ')[
                1].endswith('Singles'):
                new_li.append(sorted(events.split(','))[0].lstrip())
                for cand_event in sorted(events.split(',')):
                    extras = extras.append(pd.DataFrame(processed['Player name'][ind], cand_event.lstrip()))
                continue

            for event in events.split(','):
                if event.endswith('Doubles'):
                    pass
                elif event.endswith('Singles'):
                    new_li.append(event.lstrip())
        processed.append(extras)
        names = []
        for name in processed['Player name']:
            name = name.split(', ')
            name.reverse()
            name = [name_part.lower().capitalize() for name_part in name]
            sep = ' '
            name = sep.join(name)
            names.append(name)
        processed['Player name'] = names
        processed['Events'] = new_li
        processed = processed[processed['Events'] != 'NaN']
        processed = processed.set_index(pd.Series([ind for ind in range(1, len(processed.index) + 1)]))
        driver.close()
    return processed


tourn = query_tourn(target_site)
print(tourn)
ind = 1
base = pd.DataFrame()
if date.today().weekday() == 3:
    update_ranking_tables()
try:
    for player in tourn['Player name'].tolist():
        print(f'Looking up info for {player}')
        utr = query_utr(player)
        usta = query_usta_ranking(player.upper(), tourn['Events'][ind])
        utr['USTA rank'] = usta[0]
        utr['Player Location'] = usta[1]
        utr['Event'] = tourn['Events'][ind]
        base = base.append(utr)
        ind += 1
except:
    for player in tourn['Player name'].tolist():
        print(f'Looking up info for {player}')
        utr = query_utr(player)
        usta = query_usta_ranking(player.upper(), tourn['Events'][ind])
        utr['USTA rank'] = usta[0]
        utr['Player Location'] = usta[1]
        utr['Event'] = tourn['Events'][ind]
        base = base.append(utr)
        ind += 1
        time.sleep(1)
base = base.reset_index(drop=True)
base = base.drop_duplicates()
kaiji_summary = pd.DataFrame()
kairrie_summary = pd.DataFrame()
with pd.ExcelWriter('Tournament Roster.xlsx') as writer:
    print('Writing.', end='')
    for div in list(base['Event'].unique()):
        kairrie = query_utr('Kairrie Fu')
        print('.', end='')
        kairrie['USTA rank'] = query_usta_ranking('Kairrie Fu'.upper(), div)[0]
        kairrie['Event'] = div
        kairrie['Player Location'] = 'Greenville, NC'
        print('.', end='')
        per_base = base[base['Event'] == div]
        if kairrie['USTA rank'] != 'NaN':
            per_base = per_base.append(kairrie)
        kaiji = query_utr('Kaiji Fu')
        kaiji['USTA rank'] = query_usta_ranking('Kaiji Fu'.upper(), div)[0]
        kaiji['Event'] = div
        kaiji['Player Location'] = 'Greenville, NC'
        print('.', end='')
        if kaiji['USTA rank'] != 'NaN':
            per_base = per_base.append(kaiji)
        per_base.rename(
            {
                'singlesUtr': 'Singles UTR',
                'name': 'Name',
                'USTA rank': 'USTA Rank'
            }, axis=1, inplace=True
        )
        numeric = pd.to_numeric(per_base['USTA Rank'].replace('NaN', 99999))
        per_base['USTA Rank'] = numeric
        per_base = per_base.sort_values(by='USTA Rank')
        per_base['USTA Rank'] = per_base['USTA Rank'].replace(99999, 'Not Found')
        per_base = per_base.replace('NaN', 'Not Found')
        per_base = per_base.drop_duplicates()
        per_base['Position'] = [num + 1 for num in range(len(per_base.index))]
        if 'Kaiji Fu' in per_base['Name'].values:
            kaiji_summary = kaiji_summary.append(per_base[per_base['Name'] == 'Kaiji Fu'])
        if 'Kairrie Fu' in per_base['Name'].values:
            kairrie_summary = kairrie_summary.append(per_base[per_base['Name'] == 'Kairrie Fu'])
        per_base = per_base[['Position', 'Name', 'USTA Rank', 'Singles UTR', 'Player Location']]
        per_base.to_excel(writer, sheet_name=div, index=False)
    if not kaiji_summary.empty:
        kaiji_summary = kaiji_summary.sort_values('Event')
        kaiji_summary['Recommended'] = kaiji_summary['Event'] == 'Boys\' 14 & under Singles'
        kaiji_summary = kaiji_summary[['Position', 'Name', 'Event', 'USTA Rank', 'Singles UTR', 'Recommended']]
        kaiji_summary.to_excel(writer, sheet_name='Kaiji\'s Summary', index=False)
    if not kairrie_summary.empty:
        kairrie_summary = kairrie_summary.sort_values('Event')
        kairrie_summary['Recommended'] = kairrie_summary['Event'] == 'Girls\' 18 & under Singles'
        kairrie_summary = kairrie_summary[['Position', 'Name', 'Event', 'USTA Rank', 'Singles UTR', 'Recommended']]
        kairrie_summary.to_excel(writer, sheet_name='Kairrie\'s Summary', index=False)
wb = load_workbook('Tournament Roster.xlsx')
for sheet in wb.worksheets:
    if 'Summary' not in sheet.title:
        sheet.column_dimensions['B'].width = 30
        sheet.column_dimensions['D'].width = 10
        sheet.column_dimensions['E'].width = 30
    else:
        sheet.column_dimensions['B'].width = 30
        sheet.column_dimensions['C'].width = 30
        sheet.column_dimensions['E'].width = 10
        sheet.column_dimensions['F'].width = 15
wb.save('Tournament Roster.xlsx')
print(base)
print('Done!')
