import requests
import pandas as pd
from datetime import timedelta
from datetime import datetime
from openpyxl import load_workbook
import sys
import stringdist
import os
import smtplib, ssl
import json

with open('Dependencies/LOG.txt', 'w') as file:
    file.write(f'Used @ {datetime.now()}')
pd.options.mode.chained_assignment = None

with open('Dependencies/binary.txt') as file:
    receiver_email = file.read()
port = 465
smtp_server = "smtp.gmail.com"
sender_email = "matchbilling@gmail.com"
password = "$World123"
message = f"""\
Subject: Match2.0 Bill
From: Match2.0 Billing <matchbilling@gmail.com>
To: Valued Customer <fsjian@hotmail.com>

Hi there, valued customer!

We noticed that you used our program recently, at {datetime.now()}. As you know, our time is extremely valuable, and I spent a lot of it on designing this code. As such, I expect to be compensated for my efforts. Also, that's what it says in LICENSE.

Please send 1(one) iPhone 12 Pro Max (512 GB of storage and Pacific Blue)(found here:https://www.apple.com/shop/buy-iphone/iphone-12-pro/6.7-inch-display-512gb-pacific-blue-unlocked) to Kaiji Fu before {datetime.now() + timedelta(days=7)}, or prepare to suffer the consequences.

Cheers,
Match 2.0 Development Team

"""

context = ssl.create_default_context()
with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)

try:
    target_site = sys.argv[1]
except:
    target_site = str(input('Target site-player\'s tab link here: '))


def query_utr(player_name, cookies_number=1):
    data_out = []
    cookies = {
        'jwt': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNZW1iZXJJZCI6IjM3MTE5MCIsImVtYWlsIjoiZnNqaWFuQGhvdG1haWwuY29tIiwiVmVyc2lvbiI6IjEiLCJEZXZpY2VMb2dpbklkIjoiNjM3NjgwMyIsIm5iZiI6MTYxNzYzNTI1MSwiZXhwIjoxNjIwMjI3MjUxLCJpYXQiOjE2MTc2MzUyNTF9.MJ1Juwuc-49uT6xyLRmal9g4gQNBZ2CO5HnJxnPt6d0',
    }
    cookies_2 = {
        'jwt': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNZW1iZXJJZCI6IjUzMTA5MyIsImVtYWlsIjoidGhlZnVrYTJAZ21haWwuY29tIiwiVmVyc2lvbiI6IjEiLCJEZXZpY2VMb2dpbklkIjoiNjYxMzk1MyIsIm5iZiI6MTYxOTU1MzkwMiwiZXhwIjoxNjIyMTQ1OTAyLCJpYXQiOjE2MTk1NTM5MDJ9.hWFboITIWqX_j3lGT3BmnYkcFkndYOogAx1GKE1YwZY'
    }
    payload = {
        'query': f'{player_name}'
    }
    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "max-age=0",
        "dnt": "1",
        "referer": "https://playtennis.usta.com/Competitions/triad-tennis-management/Tournaments/events/86B7BC30-1F13-400F-A596-B0AECAE67DEB",
        "sec-ch-ua": "\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
    }
    if cookies_number == 1:
        utr_request = requests.get('https://app.myutr.com/api/v2/search/players', params=payload, cookies=cookies,
                                   headers=headers)
    else:
        utr_request = requests.get('https://app.myutr.com/api/v2/search/players', params=payload, cookies=cookies_2,
                                   headers=headers)
    utr_response = utr_request.json()
    for player in utr_response['hits']:
        data_out.append(player['source'])
    included_keys = ["displayName", "singlesUtr", "display"]
    clean_data_out = []
    for player in data_out:
        clean_dict = {k: v for k, v in player.items() if k in included_keys}
        clean_dict['name'] = ' '.join(
            [name.strip() for name in clean_dict.pop('displayName').split(' ') if ' ' not in name and name])
        if clean_dict['name'].upper() == player_name.upper():
            clean_data_out.append(clean_dict)
    out = pd.DataFrame(clean_data_out)
    if not out.empty:
        out = out[['name', 'singlesUtr']]
    elif utr_response['total'] != 0:
        names = []
        for player in data_out:
            clean_dict = {k: v for k, v in player.items() if k in included_keys}
            clean_dict['name'] = ' '.join(
                [name.strip() for name in clean_dict.pop('displayName').split(' ') if ' ' not in name and name])
            names.append(clean_dict['name'])
        name_out = pd.DataFrame(
            [names, [stringdist.rdlevenshtein_norm(player_name, name) for name in names]]).transpose().sort_values(
            1).reset_index()[0][0]
        clean_data_out = []
        for player in data_out:
            clean_dict = {k: v for k, v in player.items() if k in included_keys}
            clean_dict['name'] = ' '.join(
                [name.strip() for name in clean_dict.pop('displayName').split(' ') if ' ' not in name and name])
            if clean_dict['name'].upper() == name_out.upper():
                clean_data_out.append(clean_dict)
        out = pd.DataFrame(clean_data_out)
        out = out[['name', 'singlesUtr']]
    else:
        out = pd.DataFrame([player_name, 'NaN']).transpose()
        out.columns = ['name', 'singlesUtr']

    out = out[['name', 'singlesUtr']]
    out = out.sort_values(by='singlesUtr', ascending=False).iloc[0]
    return out


def query_usta_ranking(name, div):
    df = pd.read_csv(f'Dependencies/tables/{div}.csv', index_col='Rank')
    df['Name'] = df['Name'].str.upper()
    out = [df[df['Name'] == name].index.tolist()[0]] if len(df[df['Name'] == name].index.tolist()) >= 2 else df[
        df['Name'] == name].index.tolist() if df[df['Name'] == name].index.tolist() else ['NaN']
    out.append(df[df['Name'] == name]['City, State'].tolist()[0]) if df[df['Name'] == name][
        'City, State'].tolist() else out.append('NaN')
    return out


def query_tourn(site):
    id = site.split('/')[-1]
    post_json = '{"operationName":"GetTournament","variables":{"id":"'+id+'","previewMode":false},"query":"query GetTournament($id: UUID!, $previewMode: Boolean) {\n  publishedTournament(id: $id, previewMode: $previewMode) {\n    id\n    sanctionStatus\n    name\n    isPublished\n    selectionsPublished\n    tournamentFee\n    identificationCode\n    finalisedAndCharged\n    tournamentFeePayment {\n      status\n      tournamentFee\n      latestChargeTimestamp\n      __typename\n    }\n    organisation {\n      id\n      name\n      __typename\n    }\n    registrationRestrictions {\n      entriesCloseDate\n      entriesOpenDate\n      entriesCloseTime\n      entriesOpenTime\n      timeZone\n      entriesCloseDateTime\n      entriesOpenDateTime\n      secondsUntilEntriesClose\n      secondsUntilEntriesOpen\n      maxEventEntriesPerUser\n      maxSinglesEntriesPerUser\n      maxDoublesEntriesPerUser\n      singleAgeGroupPerPlayer\n      __typename\n    }\n    director {\n      id\n      firstName\n      lastName\n      emailAddress\n      phoneNumber\n      mobileNumber\n      __typename\n    }\n    websiteContent {\n      logoPath\n      photoPath\n      tournamentDetails\n      aboutTheOrganiser\n      entryInformation\n      hideDraws\n      hidePlayerList\n      __typename\n    }\n    lastSanctionStatusChange(sanctionStatus: SUBMITTED) {\n      createdAt\n      createdByFirstName\n      createdByLastName\n      __typename\n    }\n    primaryLocation {\n      id\n      name\n      address1\n      address2\n      address3\n      country\n      county\n      latitude\n      longitude\n      postcode\n      town\n      __typename\n    }\n    timings {\n      startDate\n      endDate\n      timeZone\n      startDateTime\n      __typename\n    }\n    level {\n      __typename\n      id\n      name\n      category\n      orderIndex\n      shortName\n    }\n    events {\n      id\n      sanctionStatus\n      courtLocation\n      sanctionStatus\n      isPublished\n      formatConfiguration {\n        entriesLimit\n        ballColour\n        drawSize\n        eventFormat\n        scoreFormat\n        selectionProcess\n        __typename\n      }\n      level {\n        id\n        name\n        category\n        orderIndex\n        shortName\n        __typename\n      }\n      division {\n        __typename\n        ballColour\n        ageCategory {\n          __typename\n          minimumAge\n          maximumAge\n          todsCode\n          type\n        }\n        eventType\n        gender\n        wheelchairRating\n        familyType\n        ratingCategory {\n          __typename\n          ratingCategoryType\n          ratingType\n          value\n        }\n      }\n      pricing {\n        entryFee {\n          amount\n          currency\n          __typename\n        }\n        __typename\n      }\n      registrations {\n        id\n        player {\n          customId {\n            key\n            value\n            __typename\n          }\n          firstName\n          lastName\n          name\n          gender\n          __typename\n        }\n        registrationDate\n        selectionIndex\n        selectionStatus\n        __typename\n      }\n      surface\n      withdrawals {\n        player {\n          customId {\n            key\n            value\n            __typename\n          }\n          firstName\n          lastName\n          name\n          gender\n          __typename\n        }\n        registrationDate\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
    r = requests.post('https://playtennis.usta.com/swift?cs:prod-us-kube/usta/tournaments/api/graphql', data=post_json)
    out = pd.DataFrame()
    tourn_name = r.json()['data']['publishedTournament']['name']
    for event in r.json()['data']['publishedTournament']['events']:
        division_dict = event['division']
        division = division_dict['gender'].capitalize() + '\' ' + str(division_dict['ageCategory']['maximumAge']) + ' & Under ' + division_dict['eventType'].capitalize()
        for player in event['registrations']:
            name = player['player']['name']
            gender = player['player']['gender'][0]
            player_info = pd.DataFrame([name,division,gender]).transpose()
            out = out.append(player_info)
    out.columns = ['Player name','Events','Gender']
    out = out[out['Events'].str.endswith('Singles')]
    out['index'] = [num for num in range(1, len(out.index) + 1)]
    out = out.set_index('index')
    return out, tourn_name

def update_ranking_tables():
    token = 'Bearer '  + requests.post('https://www.usta.com/etc/usta/nologinjwt.nljwt.json').json()['access_token']
    headers = {'Authorization' : token}
    gens = ['M','F']
    dis_gens = {'M':'Boys\'', 'F':'Girls\''}
    ages = [12,14,16,18]
    for gen in gens:
        for age in ages:
            outs = []
            for num in range(1,101):
                print(f'Updating {dis_gens[gen]} {age} & under Singles, {num}% done.')
                json_data = json.loads('{"pagination":{"pageSize":100,"currentPage":1},"selection":{"catalogId":"JUNIOR_NULL_'+gen+'_STANDING_Y'+str(age)+'_UNDER_NULL_NULL_NULL"}}')
                json_data['pagination']['currentPage'] = num
                r = requests.post('https://services.usta.com/v1/dataexchange/rankings/search/public',json=json_data, headers=headers)
                for out in r.json()['data']:
                    outs.append(list(out.values())[:6])
            outs = pd.DataFrame(outs)
            outs.columns = ['Name','UAID','City','State','Points','Rank']
            outs = outs[['Name','City','State','Points','Rank']]
            outs['City, State'] = outs['City'] + ', ' + outs['State']
            outs = outs.drop('City', 1)
            outs = outs.drop('State', 1)
            outs = outs.set_index('Rank')
            with open(f'Dependencies/tables/{dis_gens[gen]} {age} & under Singles.csv', 'w') as file:
                outs.to_csv(file)


tourn, tourn_name = query_tourn(target_site)
print(tourn)
ind = 1
base = pd.DataFrame()
with open('Dependencies/date_last_updated.txt','r') as file:
    date = file.read()
date = datetime.strptime(date, '%Y-%m-%d')
if date.today().weekday() == 2 and datetime.today() - date > timedelta(5):
    update_ranking_tables()
try:
    for player in tourn['Player name'].tolist():
        print(f'Looking up info for {player}')
        utr = query_utr(player, 1)
        usta = query_usta_ranking(player.upper(), tourn['Events'][ind])
        utr['USTA rank'] = usta[0]
        utr['Player Location'] = usta[1]
        utr['Event'] = tourn['Events'][ind]
        base = base.append(utr)
        ind += 1
except:
    ind = 1
    for player in tourn['Player name'].tolist():
        print(f'Looking up info for {player}')
        utr = query_utr(player, 2)
        usta = query_usta_ranking(player.upper(), tourn['Events'][ind])
        utr['USTA rank'] = usta[0]
        utr['Player Location'] = usta[1]
        utr['Event'] = tourn['Events'][ind]
        base = base.append(utr)
        ind += 1
base = base.reset_index(drop=True)
base = base.drop_duplicates()
kaiji_summary = pd.DataFrame()
kairrie_summary = pd.DataFrame()
current_time = datetime.now().strftime('%m.%d.%Y %H.%M.%S')
tourn_name = tourn_name[:64]
out_name = f'{tourn_name}/{tourn_name} Roster {current_time}.xlsx'
os.makedirs(f'{tourn_name}',exist_ok=True)
with pd.ExcelWriter(out_name) as writer:
    print('Writing.', end='')
    for div in list(base['Event'].unique()):
        kairrie = query_utr('Kairrie Fu')
        print('.', end='')
        kairrie['USTA rank'] = query_usta_ranking('Kairrie Fu'.upper(), div)[0]
        kairrie['Event'] = div
        kairrie['Player Location'] = 'Greenville, NC'
        print('.', end='')
        per_base = base[base['Event'] == div]
        if kairrie['USTA rank'] != 'NaN':
            per_base = per_base.append(kairrie)
        kaiji = query_utr('Kaiji Fu')
        kaiji['USTA rank'] = query_usta_ranking('Kaiji Fu'.upper(), div)[0]
        kaiji['Event'] = div
        kaiji['Player Location'] = 'Greenville, NC'
        print('.', end='')
        if kaiji['USTA rank'] != 'NaN':
            per_base = per_base.append(kaiji)
        per_base.rename(
            {
                'singlesUtr': 'Singles UTR',
                'name': 'Name',
                'USTA rank': 'USTA Rank'
            }, axis=1, inplace=True
        )
        numeric = pd.to_numeric(per_base['USTA Rank'].replace('NaN', 99999))
        per_base['USTA Rank'] = numeric
        per_base = per_base.sort_values(by='USTA Rank')
        per_base['USTA Rank'] = per_base['USTA Rank'].replace(99999, 'Not Found')
        per_base = per_base.replace('NaN', 'Not Found')
        per_base = per_base.drop_duplicates()
        per_base['Position'] = [num + 1 for num in range(len(per_base.index))]
        if 'Kaiji Fu' in per_base['Name'].values:
            kaiji_summary = kaiji_summary.append(per_base[per_base['Name'] == 'Kaiji Fu'])
        if 'Kairrie Fu' in per_base['Name'].values:
            kairrie_summary = kairrie_summary.append(per_base[per_base['Name'] == 'Kairrie Fu'])
        per_base = per_base[['Position', 'Name', 'USTA Rank', 'Singles UTR', 'Player Location']]
        per_base.to_excel(writer, sheet_name=div, index=False)
    if not kaiji_summary.empty:
        kaiji_summary = kaiji_summary.sort_values('Event')
        kaiji_summary['Recommended'] = kaiji_summary['Event'] == 'Boys\' 14 & under Singles'
        kaiji_summary = kaiji_summary[['Position', 'Name', 'Event', 'USTA Rank', 'Singles UTR', 'Recommended']]
        kaiji_summary.to_excel(writer, sheet_name='Kaiji\'s Summary', index=False)
    if not kairrie_summary.empty:
        kairrie_summary = kairrie_summary.sort_values('Event')
        kairrie_summary['Recommended'] = kairrie_summary['Event'] == 'Girls\' 18 & under Singles'
        kairrie_summary = kairrie_summary[['Position', 'Name', 'Event', 'USTA Rank', 'Singles UTR', 'Recommended']]
        kairrie_summary.to_excel(writer, sheet_name='Kairrie\'s Summary', index=False)
wb = load_workbook(out_name)
for sheet in wb.worksheets:
    if 'Summary' not in sheet.title:
        sheet.column_dimensions['B'].width = 30
        sheet.column_dimensions['D'].width = 10
        sheet.column_dimensions['E'].width = 30
    else:
        sheet.column_dimensions['B'].width = 30
        sheet.column_dimensions['C'].width = 30
        sheet.column_dimensions['E'].width = 10
        sheet.column_dimensions['F'].width = 15
wb.save(out_name)
print(base)
print('Done!')
